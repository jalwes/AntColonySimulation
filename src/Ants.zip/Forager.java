import java.util.ArrayList;

import javax.swing.JOptionPane;


public class Forager extends Ants {

	private boolean returnToNestMode = false;
	private boolean hasFood;
	//private ArrayList <ColonyNodeView> nodesTraveled = new ArrayList<>(10);
	private ArrayList <foragersNodesTraveled> nodesTraveled = new ArrayList<> (10);
	private int modCount = 1;
	
	Forager() {
		foragersNodesTraveled temp = new foragersNodesTraveled();
		temp.setxCoordinateTraveled(14);
		temp.setyCoordinateTraveled(14);
		nodesTraveled.add(0, temp);
	}
	
	public void setHasFood(boolean x) {
		hasFood = x;
	}
	
	public boolean getHasFood() { return hasFood; }
	
	public void move(ArrayList<Ants> ants, int counter, ColonyNodeView [][] nodes) {
		
		/**Testing Logic
		 */
		//Reduce number of foragers in node before moving
		int xCoordBeforeMove = ants.get(counter).getxCoordinate();
		int yCoordBeforeMove = ants.get(counter).getyCoordinate();
		nodes[xCoordBeforeMove][yCoordBeforeMove].numForagers--;
		nodes[xCoordBeforeMove][yCoordBeforeMove].setForagerCount(nodes[xCoordBeforeMove][yCoordBeforeMove].getForagerCount());
			//If forager count == 0, remove Forager icon
			if (nodes[xCoordBeforeMove][yCoordBeforeMove].getForagerCount() == 0) {
				nodes[xCoordBeforeMove][yCoordBeforeMove].hideForagerIcon(); //If there are no more foragers in this node, hide the icon
			}
		
		//Move to new node and increase forager count in that node. Show forager icon. Update modCount
		ants.get(counter).setxCoordinate(14);
		ants.get(counter).setyCoordinate(15);
		int x = ants.get(counter).getxCoordinate();
		int y = ants.get(counter).getyCoordinate();
		foragersNodesTraveled tempNode = new foragersNodesTraveled();
		tempNode.setxCoordinateTraveled(x);
		tempNode.setyCoordinateTraveled(y);
		nodesTraveled.add(modCount, tempNode);
		nodes[x][y].numForagers++;
		nodes[x][y].setForagerCount(nodes[x][y].getForagerCount());
		nodes[x][y].showForagerIcon();
		modCount++;

	}
}
