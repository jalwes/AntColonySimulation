
public class Soldier extends Ants{
	
	
}
