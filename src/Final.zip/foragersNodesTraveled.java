
public class foragersNodesTraveled {
	private int xCoordinateTraveled;
	private int yCoordinateTraveled;
	
	public int getxCoordinateTraveled() {
		return xCoordinateTraveled;
	}
	public void setxCoordinateTraveled(int xCoordinateTraveled) {
		this.xCoordinateTraveled = xCoordinateTraveled;
	}
	public int getyCoordinateTraveled() {
		return yCoordinateTraveled;
	}
	public void setyCoordinateTraveled(int yCoordinateTraveled) {
		this.yCoordinateTraveled = yCoordinateTraveled;
	}
	
}
