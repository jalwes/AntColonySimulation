import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JOptionPane;


public class Simulation implements SimulationEventListener {

	 
	static AntSimGUI gui = new AntSimGUI(); //Create new AntSimGUI
	static ColonyView grid = new ColonyView(27, 27);//Make a new 'grid' 27 x 27
	static ColonyNodeView [][] nodes = new ColonyNodeView[27][27]; //Create a new two-dimensional array of nodes
	static ArrayList<Ants> ants = new ArrayList<>(65);
	static int counter = 0;
	static int numberOfTurns = 0;
	static int days = 0;
	static int years = 0;
	/*	//Experiment with changing location of ants
		ants.get(20).setxCoordinate(2);
		ants.get(20).setyCoordinate(1);
		ants.get(20).move(perimeterCheck(ants.get(20)));//Test to make sure move() only gets sent 3 options for movement from perimeterCheck()
		
		
		//Experiment with using instanceof operator
		for (Ants s : ants) {
			System.out.println(s.getClass() + " " + s.getIdentifier() + " " + s.getxCoordinate() + ", " + s.getyCoordinate());
			if (s instanceof Soldier) {
				System.out.println("true!!");
				s.move(perimeterCheck(s));
			}
			//s.takeTurn();
		}//End instanceof experiment
		*/
		//Experiment how to see if a node is visible 
		//System.out.println("Is this square visible? " + nodes[20][20].isVisible());
		//System.out.println("How about node [14][14]. Visible? " + nodes[14][14].isVisible());

	//}

	//If an ant is on the perimeter, only give 5 choices of random movement. If on a corner, give move() only 3 choices of random movement.  
	//Otherwise, 8 choices of random movement. 
	public static int perimeterCheck(Ants s) {
		int x = s.getxCoordinate();
		int y = s.getyCoordinate();
		
		if (x == 1 || x == 27) { //If ant is in row 1 or 27, they're on the perimeter
			if (y == 1 || y == 27) {//If ant is in a corner
				return 3; //Only 3 choice of movement from a corner
			} else {
				return 5;//Only 5 choices of movement from the perimeter
			}	
		} else if (y == 1 || y == 27) { //Ant is on the left or right edge (perimeter)
			return 5;//Only 5 choices of movement from the perimeter
		} else {
			return 8;//Can move to any surrounding square
		}
	}
	public static void initializeNodes() {
		
		
		for (int i = 0; i < 27; i++) {
			for (int j = 0; j < 27; j++) {
				nodes[i][j] = new ColonyNodeView(); //Fill two dimensional array with ColonyNodeViews
				grid.addColonyNodeView(nodes[i][j], j, i); //Add nodes at specified coordinates. i = xCoordinate; j = yCoordinate 
				String coordinates = i + "," + j; //Create String for coordinate ID
				nodes[i][j].setID(coordinates); //Set coordinate ID
				//nodes[i][j].showNode(); //Show all nodes
			}
		}
	
		gui.add(grid); //Add ColonyView 'grid' to gui
		gui.initGUI(grid);
		gui.setVisible(true); //Show GUI
		
	
	} //End initialize

	public static void initializeColony() {
		
		int count = 0;
		
		//Set initial 10 soldiers
		for (int i = 1; i <= 10; i++) {
			Soldier soldier = new Soldier();
			ants.add(soldier);
			soldier.setIdentifier(i);
			soldier.setxCoordinate(14);
			soldier.setyCoordinate(14);
			count++;
		}
		nodes[14][14].setSoldierCount(count);//Set the node [14][14] to show having 10 soldier ants		
		
		//Set initial 50 forager ants
		count = 0; 
		for (int i = 11; i < 61; i++) {
			Forager forager = new Forager();
			forager.setIdentifier(i);
			ants.add(forager);
			forager.setxCoordinate(14);
			forager.setyCoordinate(14);
			nodes[14][14].numForagers++;
			count++;
		}
		//nodes[14][14].setForagerCount(count);//Set the node [14][14] to show having 50 forager ants	
		nodes[14][14].setForagerCount(nodes[14][14].getForagerCount());
		count = 0;
		
		//Set initial 4 scout ants
		for (int i = 62; i <= 65; i++) {
			Scout scout = new Scout();
			scout.setIdentifier(i);
			ants.add(scout);
			scout.setxCoordinate(14);
			scout.setyCoordinate(14);
			count++;
		}
		nodes[14][14].setScoutCount(count);//Set the node [14][14] to show having 4 scout ants	
		
		
		Collections.shuffle(ants); //
		Queen queen = new Queen();
		ants.add(0, queen);
		queen.setIdentifier(0);
		
		
		//Set queen and show icons in middle node ([14][14])
		nodes[14][14].setQueen(true);
		nodes[14][14].showQueenIcon();
		nodes[14][14].showSoldierIcon();
		nodes[14][14].showScoutIcon();
		nodes[14][14].showForagerIcon();
		nodes[14][14].setFoodAmount(1000);

		//Make queen's node and surrounding nodes visible
		for (int j = 13; j < 16; j++) {
			for (int k = 13; k < 16; k++) {
				nodes[j][k].showNode();
			}
		}

	}
	
	public void takeSingleTurn() {

		if (counter > ants.size()) { //Reset counter to start a new round of turns
			counter = 0;
		}
		
		Ants temp = ants.get(counter);
		//If this ant has reached its lifespan, remove it from the simulation
		if (temp.getLifespan() == temp.getNumberOfTurnsTaken()){
				removeAnt(temp);
				counter++;
				temp = ants.get(counter);
		}	
		
		JOptionPane.showMessageDialog(null, "In takeSingleTurn, this turn belongs to a " + temp.getClass() );

		if (temp instanceof Queen) {
			if (numberOfTurns % 10 == 0) { //If it's the start of a new day, hatch a new ant
				((Queen) temp).hatch(ants, nodes); //One of Queen's methods
			} 
			if (!((Queen) temp).eat(nodes)) { //If eat() returns false, there is no food in Queen's node. Game over. If eat() == true, eat() will reduce food in queen's node
				((Queen) temp).setCauseOfDeath(0); //set cause of death to "Starvation"
				gameOver(temp);
			}
		} else if (temp instanceof Soldier) {
			//Do stuff
		} else if (temp instanceof Scout) {
			((Scout) temp).move();
			
		} else if (temp instanceof Forager) {
			//Do stuff
			/**Needs Work. Need to figure out the pheromone situation, do they have a certain amount when instantiated? Also, move() needs work, need to determine a random move method.
			 * 
			 */
			JOptionPane.showMessageDialog(null, ants.get(counter).getxCoordinate() +" " +  ants.get(counter).getxCoordinate());
			((Forager)temp).move(ants, counter, nodes);
			JOptionPane.showMessageDialog(null, ants.get(counter).getxCoordinate() +" " +  ants.get(counter).getyCoordinate());

		} else {
			//Do Bala stuff
		} 
		
		temp.setNumberOfTurnsTaken(temp.getNumberOfTurnsTaken() + 1); //Increase number of turns taken for this ant
		counter++;
		numberOfTurns++;
		
	}
	
	public void removeAnt(Ants a) {
		if (a instanceof Queen) {
			gameOver(a);			
		} else {
			ants.remove(a);
		}
	}
	
	
	public void gameOver(Ants a) {
			JOptionPane.showMessageDialog(null, "Game Over. " + ((Queen) a).causeOfDeathToString());
			System.exit(0);
	}

	@Override
	public void simulationEventOccurred(SimulationEvent simEvent) {
		//ants.get(0).setIsAlive(false);
		//System.out.println(ants.get(0).getIsAlive());
		//Using getEventType() will return an integer from 0-6 in ascending order that corresponds to the buttons in the gui. 
		//JOptionPane.showMessageDialog(null, simEvent.getEventType());
		if (simEvent.getEventType() == 0) {
			initializeColony();
		}
		if (simEvent.getEventType() == 6) {
			takeSingleTurn();
		}
		
	}
	public void addActionEventListener() {
		// TODO Auto-generated method stub;
		gui.addSimulationEventListener(this);
	}
} //End simulation
