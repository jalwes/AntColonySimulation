
public class driver  {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Simulation sim = new Simulation();
		sim.initializeNodes();
		//sim.initializeColony();
		sim.addActionEventListener();
	}
}
