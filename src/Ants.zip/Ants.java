
public class Ants {
	private int identifier; 
	private int lifespan = 3650; //(365 day lifespan * 10 turns each day) 
	private int numberOfTurnsTaken = 0; 
	private boolean isAlive = true;
	private int xCoordinate; 
	private int yCoordinate;
	
	public int getNumberOfTurnsTaken() { return numberOfTurnsTaken; }
	public void setNumberOfTurnsTaken(int x) {
		numberOfTurnsTaken = x;
	}
	public boolean getIsAlive() { return isAlive; }
	public void setIsAlive(boolean x) {
		isAlive = x;
	}
	public int getIdentifier() {
		return identifier;
	}
	public void setIdentifier(int identifier) {
		this.identifier = identifier;
	}
	public int getLifespan() {
		return lifespan;
	}
	public void setLifespan(int lifespan) {
		this.lifespan = lifespan;
	}
	public int getxCoordinate() {
		return xCoordinate;
	}
	public void setxCoordinate(int xCoordinate) {
		this.xCoordinate = xCoordinate;
	}
	public int getyCoordinate() {
		return yCoordinate;
	}
	public void setyCoordinate(int yCoordinate) {
		this.yCoordinate = yCoordinate;
	}
	
	public void attack() {
		
	}
	
	
	
	public void randomMove() {
		
	}
	
}
