
public class Scout extends Ants{
	
	
	public void move() {
		
	}

}
