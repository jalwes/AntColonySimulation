
public class nodesWithBalas {
	private int xCoordinate;
	private int yCoordinate;
	
	nodesWithBalas() {}
	
	nodesWithBalas(int x, int y) {
		xCoordinate = x;
		yCoordinate = y;
	}
	
	public int getXCoordinateWithBala() {
		 return xCoordinate;
	}
	
	public int getYCoordinateWithBala() {
		return yCoordinate;
	}
}
